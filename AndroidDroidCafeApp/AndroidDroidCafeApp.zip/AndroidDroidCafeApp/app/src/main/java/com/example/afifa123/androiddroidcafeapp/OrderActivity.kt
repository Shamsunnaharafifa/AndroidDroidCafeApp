package com.example.afifa123.androiddroidcafeapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import org.jetbrains.anko.spinner

class OrderActivity : AppCompatActivity(),AdapterView.OnItemSelectedListener{


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        val intent  = intent

        var message = intent.getStringExtra("EXTRA_MESSAGE")
        var textView: TextView = findViewById(R.id.order_text_view)
        textView.text  = message

        var spinner: Spinner= findViewById(R.id.level_spinner)
        if(spinner!=null){
            spinner.onItemSelectedListener
        }

        val adapter = ArrayAdapter.createFromResource(
            this,R.array.labels_array,android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.adapter
    }
    private fun displayToast(message: String){
        Toast.makeText(applicationContext,message, Toast.LENGTH_SHORT).show()
    }

    fun onRadioButtonClicked(view: View) {
        val checked = (view as RadioButton).isChecked
        when (view.getId()) {
           R.id.same_day -> displayToast(getString(R.string.same_day_messenger_service_text))
            R.id.next_day -> displayToast(getString(R.string.next_messenger_service_text))
            R.id.pick_up -> displayToast(getString(R.string.pick_up_service_text))
        }
    }
    override fun onNothingSelected(parent: AdapterView<*>?) {

    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val spinnerLabel = 
    }
}

